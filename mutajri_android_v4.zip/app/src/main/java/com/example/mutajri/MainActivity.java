package com.example.mutajri;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Space;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class MainActivity extends Activity {

    // ---------- colors ----------
    final int GREEN = Color.rgb(22, 138, 74);
    final int DARK_GREEN = Color.rgb(18, 107, 59);
    final int PALE = Color.rgb(243, 251, 245);
    final int TEXT = Color.rgb(25, 45, 33);
    final int RED = Color.rgb(180, 70, 50);
    final int ORANGE = Color.rgb(180, 110, 0);

    static final int REQ_EXPORT = 101;
    static final int REQ_IMPORT = 102;
    static final String[] DATA_KEYS = {"products", "sales", "shifts", "customers", "expenses"};

    LinearLayout root, content;
    SharedPreferences prefs;
    int reportPeriod = 0; // 0 = today, 1 = last 7 days, 2 = this month, 3 = all

    @Override
    public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("mutajri", MODE_PRIVATE);
        migrateOldData();
        buildShell();
        showHome();
    }

    // ---------- storage helpers ----------
    JSONArray arr(String key) {
        try {
            return new JSONArray(prefs.getString(key, "[]"));
        } catch (Exception e) {
            return new JSONArray();
        }
    }

    void save(String key, JSONArray a) {
        prefs.edit().putString(key, a.toString()).apply();
    }

    String pref(String key, String def) {
        return prefs.getString(key, def);
    }

    void put(String key, String value) {
        prefs.edit().putString(key, value).apply();
    }

    JSONArray products() { return arr("products"); }
    JSONArray sales() { return arr("sales"); }
    JSONArray shifts() { return arr("shifts"); }
    JSONArray customers() { return arr("customers"); }
    JSONArray expenses() { return arr("expenses"); }

    JSONObject obj(JSONArray a, int i) {
        try {
            return a.getJSONObject(i);
        } catch (Exception e) {
            return new JSONObject();
        }
    }

    boolean activeShift() { return prefs.getBoolean("shift_active", false); }
    String shiftId() { return pref("shift_id", ""); }

    String now() {
        return new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(new Date());
    }

    String dateOnly() {
        return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
    }

    String daysAgo(int d) {
        Calendar c = Calendar.getInstance();
        c.add(Calendar.DAY_OF_YEAR, -d);
        return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(c.getTime());
    }

    String displayDate(String s) {
        try {
            return new SimpleDateFormat("dd/MM/yyyy", Locale.US)
                    .format(new SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(s));
        } catch (Exception e) {
            return s;
        }
    }

    double n(Object o) {
        try {
            return Double.parseDouble(String.valueOf(o));
        } catch (Exception e) {
            return 0;
        }
    }

    String fmt(double d) {
        if (Math.abs(d) < 0.005) d = 0;
        if (d == Math.rint(d)) return String.format(Locale.US, "%.0f", d);
        return String.format(Locale.US, "%.2f", d);
    }

    String money(double d) {
        return fmt(d) + " ج.س";
    }

    void toast(String m) {
        Toast.makeText(this, m, Toast.LENGTH_SHORT).show();
    }

    // Brings very old data (from the first versions) up to the current format.
    void migrateOldData() {
        JSONArray s = arr("sales");
        JSONArray out = new JSONArray();
        boolean changed = false;
        for (int i = 0; i < s.length(); i++) {
            try {
                Object x = s.get(i);
                if (x instanceof JSONObject) {
                    out.put(x);
                } else {
                    JSONObject o = new JSONObject();
                    o.put("total", n(x));
                    o.put("qty", 1);
                    o.put("product", "بيع سابق");
                    o.put("time", now());
                    o.put("shiftId", "");
                    o.put("cost", 0);
                    out.put(o);
                    changed = true;
                }
            } catch (Exception ignored) {
            }
        }
        if (changed) save("sales", out);

        JSONArray c = arr("customers");
        boolean cChanged = false;
        for (int i = 0; i < c.length(); i++) {
            try {
                JSONObject o = c.getJSONObject(i);
                if (!o.has("id")) {
                    o.put("id", String.valueOf(System.currentTimeMillis() + i));
                    cChanged = true;
                }
            } catch (Exception ignored) {
            }
        }
        if (cChanged) save("customers", c);
    }

    // ---------- UI helpers ----------
    int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    TextView tv(String s, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        t.setTypeface(Typeface.DEFAULT, bold ? Typeface.BOLD : Typeface.NORMAL);
        t.setPadding(dp(3), dp(3), dp(3), dp(3));
        t.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        return t;
    }

    Button btn(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextSize(15);
        b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        b.setGravity(Gravity.CENTER);
        b.setBackgroundResource(R.drawable.green_button);
        b.setPadding(dp(8), dp(2), dp(8), dp(2));
        return b;
    }

    LinearLayout card() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(12), dp(10), dp(12), dp(10));
        l.setBackgroundResource(R.drawable.card_bg);
        l.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        return l;
    }

    LinearLayout stat(String label, String value, int color) {
        LinearLayout c = card();
        c.addView(tv(label, 13, Color.DKGRAY, false));
        c.addView(tv(value, 20, color, true));
        return c;
    }

    // Two cards side by side
    LinearLayout row(View first, View second) {
        LinearLayout r = new LinearLayout(this);
        r.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        r.addView(first, new LinearLayout.LayoutParams(0, -2, 1));
        r.addView(new Space(this), new LinearLayout.LayoutParams(dp(8), 1));
        r.addView(second, new LinearLayout.LayoutParams(0, -2, 1));
        return r;
    }

    LinearLayout.LayoutParams lp(int heightDp) {
        return new LinearLayout.LayoutParams(-1, dp(heightDp));
    }

    LinearLayout.LayoutParams wrap() {
        return new LinearLayout.LayoutParams(-1, -2);
    }

    void addSpace(int heightDp) {
        content.addView(new Space(this), new LinearLayout.LayoutParams(1, dp(heightDp)));
    }

    // mode: 0 = text, 1 = decimal number, 2 = whole number
    EditText field(String hint, int mode) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setGravity(Gravity.RIGHT);
        if (mode == 1) e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        if (mode == 2) e.setInputType(InputType.TYPE_CLASS_NUMBER);
        return e;
    }

    void buildShell() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(PALE);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(16), dp(8), dp(16), dp(8));
        bar.setBackgroundColor(DARK_GREEN);
        bar.addView(tv("متجري", 22, Color.WHITE, true), new LinearLayout.LayoutParams(0, dp(40), 1));
        root.addView(bar);

        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(12), dp(12), dp(12), dp(8));
        content.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        ScrollView sc = new ScrollView(this);
        sc.addView(content);
        root.addView(sc, new LinearLayout.LayoutParams(-1, 0, 1));

        HorizontalScrollView navScroll = new HorizontalScrollView(this);
        navScroll.setFillViewport(true);
        navScroll.setHorizontalScrollBarEnabled(false);
        LinearLayout nav = new LinearLayout(this);
        nav.setPadding(dp(4), dp(4), dp(4), dp(4));
        nav.setBackgroundColor(Color.WHITE);
        nav.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        String[] labels = {"الرئيسية", "المبيعات", "المنتجات", "المصروفات",
                "العملاء والديون", "التقارير", "سجل الوردية", "النسخ الاحتياطي"};
        for (int i = 0; i < labels.length; i++) {
            final int k = i;
            Button nb = btn(labels[i]);
            nb.setTextSize(14);
            nb.setTextColor(GREEN);
            nb.setBackgroundColor(Color.TRANSPARENT);
            nb.setOnClickListener(v -> openPage(k));
            nav.addView(nb, new LinearLayout.LayoutParams(dp(118), dp(48)));
        }
        navScroll.addView(nav);
        root.addView(navScroll, new LinearLayout.LayoutParams(-1, dp(56)));
        setContentView(root);
    }

    void openPage(int k) {
        if (k == 0) showHome();
        else if (k == 1) showSales();
        else if (k == 2) showProducts();
        else if (k == 3) showExpenses();
        else if (k == 4) showCustomers();
        else if (k == 5) showReports();
        else if (k == 6) showShiftHistory();
        else showBackup();
    }

    void clear(String title) {
        content.removeAllViews();
        TextView h = tv(title, 24, TEXT, true);
        h.setPadding(dp(3), dp(3), dp(3), dp(10));
        content.addView(h);
    }

    // ---------- calculations ----------
    // returns {sales total, cost total, number of sales}
    double[] shiftStats(String id) {
        double total = 0, cost = 0, count = 0;
        if (!id.isEmpty()) {
            JSONArray a = sales();
            for (int i = 0; i < a.length(); i++) {
                JSONObject x = obj(a, i);
                if (id.equals(x.optString("shiftId"))) {
                    total += x.optDouble("total", 0);
                    cost += x.optDouble("cost", 0);
                    count++;
                }
            }
        }
        return new double[]{total, cost, count};
    }

    boolean inPeriod(String time, int period) {
        if (period == 3) return true;
        if (time == null || time.length() < 10) return false;
        String day = time.substring(0, 10);
        if (period == 0) return day.equals(dateOnly());
        if (period == 1) return day.compareTo(daysAgo(6)) >= 0;
        return day.substring(0, 7).equals(dateOnly().substring(0, 7));
    }

    // returns {sales total, cost total, number of sales, credit (unpaid) sales total}
    double[] periodStats(int period) {
        double total = 0, cost = 0, count = 0, credit = 0;
        JSONArray a = sales();
        for (int i = 0; i < a.length(); i++) {
            JSONObject x = obj(a, i);
            if (inPeriod(x.optString("time"), period)) {
                total += x.optDouble("total", 0);
                cost += x.optDouble("cost", 0);
                count++;
                if (x.optBoolean("credit", false)) credit += x.optDouble("total", 0);
            }
        }
        return new double[]{total, cost, count, credit};
    }

    double periodExpenses(int period) {
        double total = 0;
        JSONArray a = expenses();
        for (int i = 0; i < a.length(); i++) {
            JSONObject x = obj(a, i);
            if (inPeriod(x.optString("time"), period)) total += x.optDouble("amount", 0);
        }
        return total;
    }

    double totalDebts() {
        double t = 0;
        JSONArray a = customers();
        for (int i = 0; i < a.length(); i++) t += obj(a, i).optDouble("debt", 0);
        return t;
    }

    boolean hasProductWithoutCost() {
        JSONArray p = products();
        for (int i = 0; i < p.length(); i++) {
            if (obj(p, i).optDouble("cost", 0) <= 0) return true;
        }
        return false;
    }

    boolean needsBackup() {
        if (sales().length() == 0 && products().length() == 0) return false;
        String last = pref("last_backup", "");
        if (last.length() < 10) return true;
        return last.substring(0, 10).compareTo(daysAgo(7)) < 0;
    }

    // ---------- HOME ----------
    void showHome() {
        clear("السلام عليكم 👋");

        if (needsBackup()) {
            LinearLayout warn = card();
            warn.addView(tv("💾 احفظ نسخة احتياطية من بياناتك. البيانات موجودة على هذا الهاتف فقط.", 13, ORANGE, false));
            Button go = btn("حفظ نسخة الآن");
            go.setOnClickListener(v -> showBackup());
            warn.addView(go, lp(44));
            content.addView(warn, wrap());
            addSpace(10);
        }

        LinearLayout shift = card();
        shift.addView(tv(activeShift() ? "الوردية الحالية" : "لا توجد وردية نشطة", 16, TEXT, true));
        if (activeShift()) shift.addView(tv("بدأت: " + pref("shift_start", ""), 13, Color.DKGRAY, false));
        Button shiftBtn = btn(activeShift() ? "⏹ إنهاء الوردية" : "▶ بدء الوردية");
        shiftBtn.setOnClickListener(v -> {
            if (activeShift()) endShift();
            else startShift();
        });
        shift.addView(shiftBtn, lp(48));
        content.addView(shift, wrap());
        addSpace(10);

        double[] st = shiftStats(activeShift() ? shiftId() : "");
        double shiftProfit = st[0] - st[1];
        content.addView(row(stat("مبيعات الوردية", money(st[0]), GREEN),
                stat("ربح الوردية", money(shiftProfit), shiftProfit >= 0 ? GREEN : RED)), wrap());
        addSpace(8);
        content.addView(row(stat("المنتجات", String.valueOf(products().length()), GREEN),
                stat("عمليات البيع", String.valueOf((int) st[2]), GREEN)), wrap());
        addSpace(12);

        Button sell = btn("🛒  تسجيل بيع");
        sell.setOnClickListener(v -> showSales());
        content.addView(sell, lp(50));
        addSpace(8);
        Button add = btn("📦  إضافة بضاعة");
        add.setOnClickListener(v -> addProductDialog(-1));
        content.addView(add, lp(50));
        addSpace(8);
        Button inv = btn("🔍  جرد المخزون");
        inv.setOnClickListener(v -> showProducts());
        content.addView(inv, lp(50));
        addSpace(12);

        LinearLayout notes = card();
        notes.addView(tv("📝 ملاحظات الوردية", 16, TEXT, true));
        EditText ne = new EditText(this);
        ne.setHint("اكتب ملاحظاتك هنا...");
        ne.setGravity(Gravity.TOP | Gravity.RIGHT);
        ne.setText(pref("current_notes", ""));
        ne.setMinHeight(dp(90));
        ne.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        ne.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            public void onTextChanged(CharSequence s, int start, int before, int count) {
                put("current_notes", s.toString());
            }

            public void afterTextChanged(Editable e) {
            }
        });
        notes.addView(ne, wrap());
        content.addView(notes, wrap());
        addSpace(12);

        LinearLayout low = card();
        low.addView(tv("⚠ المخزون المنخفض", 16, TEXT, true));
        JSONArray p = products();
        boolean any = false;
        for (int i = 0; i < p.length(); i++) {
            JSONObject o = obj(p, i);
            if (o.optInt("qty", 0) <= 3) {
                any = true;
                low.addView(tv(o.optString("name") + " — " + o.optInt("qty", 0) + " متوفر", 14, ORANGE, false));
            }
        }
        if (!any) low.addView(tv("لا توجد أصناف منخفضة المخزون.", 14, Color.DKGRAY, false));
        content.addView(low, wrap());
    }

    void startShift() {
        String id = String.valueOf(System.currentTimeMillis());
        prefs.edit().putBoolean("shift_active", true).putString("shift_id", id)
                .putString("shift_start", now()).putString("current_notes", "").apply();
        showHome();
    }

    void endShift() {
        new AlertDialog.Builder(this).setTitle("إنهاء الوردية")
                .setMessage("سيتم حفظ المبيعات والملاحظات في سجل الوردية وبدء صفحة جديدة.")
                .setNegativeButton("إلغاء", null)
                .setPositiveButton("إنهاء", (d, w) -> {
                    try {
                        double[] st = shiftStats(shiftId());
                        JSONObject sh = new JSONObject();
                        sh.put("id", shiftId());
                        sh.put("date", dateOnly());
                        sh.put("start", pref("shift_start", ""));
                        sh.put("end", now());
                        sh.put("sales", st[0]);
                        sh.put("profit", st[0] - st[1]);
                        sh.put("count", (int) st[2]);
                        sh.put("notes", pref("current_notes", ""));
                        JSONArray all = shifts();
                        all.put(sh);
                        save("shifts", all);
                    } catch (Exception ignored) {
                    }
                    prefs.edit().putBoolean("shift_active", false).putString("shift_id", "")
                            .putString("shift_start", "").putString("current_notes", "").apply();
                    showHome();
                }).show();
    }

    // ---------- PRODUCTS ----------
    void showProducts() {
        clear("المنتجات");
        Button add = btn("+  إضافة منتج");
        add.setOnClickListener(v -> addProductDialog(-1));
        content.addView(add, lp(48));
        addSpace(10);
        JSONArray p = products();
        if (p.length() == 0) {
            content.addView(tv("لا توجد منتجات. ابدأ بإضافة أول منتج.", 16, TEXT, false));
            return;
        }
        for (int i = 0; i < p.length(); i++) {
            final int ix = i;
            JSONObject o = obj(p, i);
            double price = o.optDouble("price", 0);
            double cost = o.optDouble("cost", 0);
            LinearLayout c = card();
            c.addView(tv(o.optString("name"), 18, TEXT, true));
            c.addView(tv("سعر البيع: " + money(price) + "   •   الكمية: " + o.optInt("qty", 0), 14, Color.DKGRAY, false));
            if (cost > 0) {
                c.addView(tv("سعر الشراء: " + money(cost) + "   •   ربح القطعة: " + money(price - cost), 14, GREEN, false));
            } else {
                c.addView(tv("⚠ سعر الشراء غير مسجل (لن يظهر الربح)", 13, ORANGE, false));
            }
            Button edit = btn("تعديل المنتج");
            edit.setOnClickListener(v -> addProductDialog(ix));
            c.addView(edit, lp(44));
            content.addView(c, wrap());
            addSpace(8);
        }
    }

    void addProductDialog(final int index) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(8), dp(16), dp(4));
        final EditText name = field("اسم المنتج", 0);
        final EditText cost = field("سعر الشراء (التكلفة)", 1);
        final EditText price = field("سعر البيع", 1);
        final EditText qty = field("الكمية", 2);
        box.addView(name);
        box.addView(cost);
        box.addView(price);
        box.addView(qty);
        if (index >= 0) {
            JSONObject cur = obj(products(), index);
            name.setText(cur.optString("name"));
            if (cur.optDouble("cost", 0) > 0) cost.setText(fmt(cur.optDouble("cost", 0)));
            price.setText(fmt(cur.optDouble("price", 0)));
            qty.setText(String.valueOf(cur.optInt("qty", 0)));
        }
        AlertDialog.Builder builder = new AlertDialog.Builder(this)
                .setTitle(index < 0 ? "إضافة منتج" : "تعديل المنتج")
                .setView(box)
                .setNegativeButton("إلغاء", null);
        builder.setPositiveButton("حفظ", (d, w) -> {
            try {
                String nm = name.getText().toString().trim();
                double pr = Double.parseDouble(price.getText().toString().trim());
                String costText = cost.getText().toString().trim();
                double co = costText.isEmpty() ? 0 : Double.parseDouble(costText);
                int q = Integer.parseInt(qty.getText().toString().trim());
                if (nm.isEmpty() || pr < 0 || co < 0 || q < 0) throw new Exception();
                JSONArray all = products();
                JSONObject o = index < 0 ? new JSONObject() : all.getJSONObject(index);
                o.put("name", nm);
                o.put("price", pr);
                o.put("cost", co);
                o.put("qty", q);
                if (index < 0) all.put(o);
                save("products", all);
                showProducts();
            } catch (Exception e) {
                toast("أدخل بيانات صحيحة (الاسم وسعر البيع والكمية).");
            }
        });
        if (index >= 0) builder.setNeutralButton("حذف", (d, w) -> deleteProduct(index));
        builder.show();
    }

    void deleteProduct(final int index) {
        new AlertDialog.Builder(this).setTitle("حذف المنتج")
                .setMessage("هل تريد حذف هذا المنتج؟ (المبيعات السابقة تبقى محفوظة)")
                .setNegativeButton("إلغاء", null)
                .setPositiveButton("حذف", (d, w) -> {
                    JSONArray all = products();
                    all.remove(index);
                    save("products", all);
                    showProducts();
                }).show();
    }

    // ---------- SALES ----------
    void showSales() {
        clear("المبيعات");
        if (!activeShift()) {
            content.addView(tv("ابدأ الوردية أولاً لتسجيل المبيعات.", 16, TEXT, false));
            Button st = btn("▶ بدء الوردية");
            st.setOnClickListener(v -> startShift());
            content.addView(st, lp(48));
            return;
        }
        final JSONArray p = products();
        if (p.length() == 0) {
            content.addView(tv("أضف منتجات أولاً حتى تتمكن من تسجيل البيع.", 16, TEXT, false));
            return;
        }
        final JSONArray cust = customers();

        final Spinner sp = new Spinner(this);
        String[] names = new String[p.length()];
        for (int i = 0; i < p.length(); i++) {
            JSONObject o = obj(p, i);
            names[i] = o.optString("name") + " — " + fmt(o.optDouble("price", 0)) + " ج.س (" + o.optInt("qty", 0) + ")";
        }
        sp.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, names));
        content.addView(tv("اختر المنتج", 15, TEXT, true));
        content.addView(sp, lp(52));
        addSpace(6);

        final EditText q = field("الكمية", 2);
        q.setText("1");
        content.addView(tv("الكمية", 15, TEXT, true));
        content.addView(q, lp(52));
        addSpace(6);

        final Spinner pay = new Spinner(this);
        pay.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item,
                new String[]{"نقداً", "آجل (دين على عميل)"}));
        content.addView(tv("طريقة الدفع", 15, TEXT, true));
        content.addView(pay, lp(52));

        final Spinner cs = new Spinner(this);
        String[] custNames = new String[cust.length()];
        for (int i = 0; i < cust.length(); i++) custNames[i] = obj(cust, i).optString("name");
        cs.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, custNames));
        cs.setVisibility(View.GONE);
        content.addView(cs, lp(52));
        pay.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                cs.setVisibility(position == 1 ? View.VISIBLE : View.GONE);
            }

            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
        addSpace(10);

        Button record = btn("تسجيل البيع");
        record.setOnClickListener(v -> {
            try {
                int idx = sp.getSelectedItemPosition();
                int qty = Integer.parseInt(q.getText().toString().trim());
                boolean credit = pay.getSelectedItemPosition() == 1;
                JSONObject prod = p.getJSONObject(idx);
                int stock = prod.optInt("qty", 0);
                if (qty <= 0 || qty > stock) {
                    toast("الكمية غير متاحة.");
                    return;
                }
                JSONObject buyer = null;
                if (credit) {
                    if (cust.length() == 0) {
                        toast("أضف عميلاً أولاً من شاشة العملاء والديون.");
                        return;
                    }
                    buyer = cust.getJSONObject(cs.getSelectedItemPosition());
                }
                double total = prod.optDouble("price", 0) * qty;
                double cost = prod.optDouble("cost", 0) * qty;

                JSONObject sale = new JSONObject();
                sale.put("product", prod.optString("name"));
                sale.put("qty", qty);
                sale.put("total", total);
                sale.put("cost", cost);
                sale.put("time", now());
                sale.put("shiftId", shiftId());
                sale.put("credit", credit);

                if (buyer != null) {
                    sale.put("customerId", buyer.optString("id"));
                    sale.put("customer", buyer.optString("name"));
                    JSONArray hist = buyer.optJSONArray("history");
                    if (hist == null) hist = new JSONArray();
                    JSONObject entry = new JSONObject();
                    entry.put("amount", total);
                    entry.put("add", true);
                    entry.put("time", now());
                    entry.put("note", "بيع: " + prod.optString("name") + " × " + qty);
                    hist.put(entry);
                    buyer.put("history", hist);
                    buyer.put("debt", buyer.optDouble("debt", 0) + total);
                    save("customers", cust);
                }

                prod.put("qty", stock - qty);
                p.put(idx, prod);
                save("products", p);
                JSONArray salesArr = sales();
                salesArr.put(sale);
                save("sales", salesArr);
                toast("تم تسجيل البيع بنجاح ✓");
                showHome();
            } catch (Exception e) {
                toast("تحقق من البيانات.");
            }
        });
        content.addView(record, lp(52));
        addSpace(12);

        LinearLayout list = card();
        list.addView(tv("مبيعات الوردية الحالية", 16, TEXT, true));
        JSONArray all = sales();
        boolean any = false;
        for (int i = all.length() - 1; i >= 0; i--) {
            JSONObject x = obj(all, i);
            if (shiftId().equals(x.optString("shiftId"))) {
                any = true;
                String line = x.optString("product") + " × " + x.optInt("qty", 1) + " — " + money(x.optDouble("total", 0));
                if (x.optBoolean("credit", false)) line += "  (آجل: " + x.optString("customer") + ")";
                list.addView(tv(line, 14, TEXT, false));
            }
        }
        if (!any) list.addView(tv("لا توجد مبيعات بعد.", 14, Color.DKGRAY, false));
        content.addView(list, wrap());
    }

    // ---------- EXPENSES ----------
    void showExpenses() {
        clear("المصروفات");
        Button add = btn("+ إضافة مصروف");
        add.setOnClickListener(v -> expenseDialog());
        content.addView(add, lp(48));
        addSpace(10);
        content.addView(row(stat("مصروفات اليوم", money(periodExpenses(0)), RED),
                stat("مصروفات الشهر", money(periodExpenses(2)), RED)), wrap());
        addSpace(10);

        JSONArray a = expenses();
        if (a.length() == 0) {
            content.addView(tv("لا توجد مصروفات مسجلة. سجّل الإيجار والكهرباء والنقل وغيرها لتعرف صافي ربحك.", 15, TEXT, false));
            return;
        }
        for (int i = a.length() - 1; i >= 0; i--) {
            final int ix = i;
            JSONObject o = obj(a, i);
            LinearLayout c = card();
            c.addView(tv(o.optString("desc"), 17, TEXT, true));
            c.addView(tv(money(o.optDouble("amount", 0)), 16, RED, true));
            c.addView(tv(o.optString("time"), 12, Color.DKGRAY, false));
            Button del = btn("حذف");
            del.setOnClickListener(v -> deleteExpense(ix));
            c.addView(del, lp(40));
            content.addView(c, wrap());
            addSpace(8);
        }
    }

    void expenseDialog() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(8), dp(16), dp(4));
        final EditText desc = field("وصف المصروف (إيجار، كهرباء، نقل...)", 0);
        final EditText amount = field("المبلغ", 1);
        box.addView(desc);
        box.addView(amount);
        new AlertDialog.Builder(this).setTitle("إضافة مصروف").setView(box)
                .setNegativeButton("إلغاء", null)
                .setPositiveButton("حفظ", (d, w) -> {
                    try {
                        String ds = desc.getText().toString().trim();
                        double am = Double.parseDouble(amount.getText().toString().trim());
                        if (ds.isEmpty() || am <= 0) throw new Exception();
                        JSONObject o = new JSONObject();
                        o.put("desc", ds);
                        o.put("amount", am);
                        o.put("time", now());
                        JSONArray all = expenses();
                        all.put(o);
                        save("expenses", all);
                        showExpenses();
                    } catch (Exception e) {
                        toast("أدخل الوصف والمبلغ بشكل صحيح.");
                    }
                }).show();
    }

    void deleteExpense(final int index) {
        new AlertDialog.Builder(this).setTitle("حذف المصروف")
                .setMessage("هل تريد حذف هذا المصروف؟")
                .setNegativeButton("إلغاء", null)
                .setPositiveButton("حذف", (d, w) -> {
                    JSONArray all = expenses();
                    all.remove(index);
                    save("expenses", all);
                    showExpenses();
                }).show();
    }

    // ---------- REPORTS ----------
    void showReports() {
        clear("التقارير");

        String[] labels = {"اليوم", "7 أيام", "الشهر", "الكل"};
        LinearLayout periods = new LinearLayout(this);
        periods.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        for (int i = 0; i < labels.length; i++) {
            final int k = i;
            Button pb = btn(labels[i]);
            if (i != reportPeriod) {
                pb.setBackgroundColor(Color.WHITE);
                pb.setTextColor(GREEN);
            }
            pb.setOnClickListener(v -> {
                reportPeriod = k;
                showReports();
            });
            LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(0, dp(44), 1);
            pp.setMargins(dp(2), 0, dp(2), 0);
            periods.addView(pb, pp);
        }
        content.addView(periods, wrap());
        addSpace(10);

        double[] st = periodStats(reportPeriod);
        double exp = periodExpenses(reportPeriod);
        double gross = st[0] - st[1];
        double net = gross - exp;

        content.addView(row(stat("المبيعات", money(st[0]), GREEN),
                stat("عدد العمليات", String.valueOf((int) st[2]), TEXT)), wrap());
        addSpace(8);
        content.addView(row(stat("تكلفة البضاعة", money(st[1]), TEXT),
                stat("الربح الإجمالي", money(gross), gross >= 0 ? GREEN : RED)), wrap());
        addSpace(8);
        content.addView(row(stat("المصروفات", money(exp), RED),
                stat("صافي الربح", money(net), net >= 0 ? GREEN : RED)), wrap());
        addSpace(8);

        if (st[3] > 0) {
            content.addView(tv("منها بيع آجل (لم يُسدد بعد): " + money(st[3]), 14, ORANGE, false));
        }
        if (hasProductWithoutCost()) {
            content.addView(tv("⚠ بعض المنتجات بدون سعر شراء، لذلك قد يظهر الربح أعلى من الحقيقي. عدّل المنتج وأضف سعر الشراء.", 13, ORANGE, false));
        }
        addSpace(8);

        // best sellers in the selected period
        Map<String, double[]> map = new HashMap<String, double[]>();
        JSONArray a = sales();
        for (int i = 0; i < a.length(); i++) {
            JSONObject x = obj(a, i);
            if (!inPeriod(x.optString("time"), reportPeriod)) continue;
            String key = x.optString("product");
            double[] v = map.get(key);
            if (v == null) {
                v = new double[]{0, 0};
                map.put(key, v);
            }
            v[0] += x.optInt("qty", 1);
            v[1] += x.optDouble("total", 0);
        }
        ArrayList<Map.Entry<String, double[]>> list = new ArrayList<Map.Entry<String, double[]>>(map.entrySet());
        Collections.sort(list, new Comparator<Map.Entry<String, double[]>>() {
            public int compare(Map.Entry<String, double[]> m1, Map.Entry<String, double[]> m2) {
                return Double.compare(m2.getValue()[0], m1.getValue()[0]);
            }
        });
        LinearLayout top = card();
        top.addView(tv("🏆 الأكثر مبيعاً", 16, TEXT, true));
        if (list.isEmpty()) top.addView(tv("لا توجد مبيعات في هذه الفترة.", 14, Color.DKGRAY, false));
        for (int i = 0; i < list.size() && i < 5; i++) {
            Map.Entry<String, double[]> en = list.get(i);
            top.addView(tv(en.getKey() + " — " + fmt(en.getValue()[0]) + " قطعة — " + money(en.getValue()[1]), 14, TEXT, false));
        }
        content.addView(top, wrap());
        addSpace(10);

        LinearLayout debts = card();
        debts.addView(tv("ديون العملاء غير المسددة (حالياً)", 14, Color.DKGRAY, false));
        debts.addView(tv(money(totalDebts()), 20, totalDebts() > 0 ? RED : GREEN, true));
        content.addView(debts, wrap());
    }

    // ---------- SHIFT HISTORY ----------
    void showShiftHistory() {
        clear("سجل الوردية");
        JSONArray a = shifts();
        if (a.length() == 0) {
            content.addView(tv("لا توجد ورديات مكتملة بعد.", 16, TEXT, false));
            return;
        }
        for (int i = a.length() - 1; i >= 0; i--) {
            final JSONObject sh = obj(a, i);
            LinearLayout c = card();
            c.addView(tv("وردية — " + displayDate(sh.optString("date")), 18, TEXT, true));
            String line = "المبيعات: " + money(sh.optDouble("sales", 0)) + "  •  العمليات: " + sh.optInt("count", 0);
            c.addView(tv(line, 14, Color.DKGRAY, false));
            if (sh.has("profit")) c.addView(tv("الربح: " + money(sh.optDouble("profit", 0)), 14, GREEN, false));
            Button detail = btn("عرض التفاصيل");
            detail.setOnClickListener(v -> showShiftDetails(sh));
            c.addView(detail, lp(44));
            content.addView(c, wrap());
            addSpace(8);
        }
    }

    void showShiftDetails(JSONObject sh) {
        clear("تفاصيل الوردية");
        LinearLayout c = card();
        c.addView(tv("التاريخ: " + displayDate(sh.optString("date")), 16, TEXT, true));
        c.addView(tv("البداية: " + sh.optString("start"), 14, Color.DKGRAY, false));
        c.addView(tv("النهاية: " + sh.optString("end"), 14, Color.DKGRAY, false));
        c.addView(tv("مبيعات الوردية: " + money(sh.optDouble("sales", 0)), 18, GREEN, true));
        if (sh.has("profit")) c.addView(tv("ربح الوردية: " + money(sh.optDouble("profit", 0)), 16, GREEN, true));
        c.addView(tv("عمليات البيع: " + sh.optInt("count", 0), 14, TEXT, false));
        content.addView(c, wrap());
        addSpace(10);

        LinearLayout notes = card();
        notes.addView(tv("📝 ملاحظات الوردية", 16, TEXT, true));
        String nt = sh.optString("notes", "");
        notes.addView(tv(nt.isEmpty() ? "لا توجد ملاحظات." : nt, 14, TEXT, false));
        content.addView(notes, wrap());
        addSpace(10);

        LinearLayout box = card();
        box.addView(tv("تفاصيل المبيعات", 16, TEXT, true));
        JSONArray s = sales();
        boolean any = false;
        for (int i = 0; i < s.length(); i++) {
            JSONObject x = obj(s, i);
            if (sh.optString("id").equals(x.optString("shiftId"))) {
                any = true;
                String line = x.optString("product") + " × " + x.optInt("qty", 1) + " — " + money(x.optDouble("total", 0));
                if (x.optBoolean("credit", false)) line += "  (آجل: " + x.optString("customer") + ")";
                box.addView(tv(line, 14, TEXT, false));
            }
        }
        if (!any) box.addView(tv("لا توجد تفاصيل مسجلة لهذه الوردية.", 14, Color.DKGRAY, false));
        content.addView(box, wrap());
    }

    // ---------- CUSTOMERS & DEBTS ----------
    void showCustomers() {
        clear("العملاء والديون");
        Button add = btn("+ إضافة عميل");
        add.setOnClickListener(v -> customerDialog(-1));
        content.addView(add, lp(48));
        addSpace(10);
        JSONArray a = customers();
        if (a.length() == 0) {
            content.addView(tv("لا يوجد عملاء بعد.", 16, TEXT, false));
            return;
        }
        for (int i = 0; i < a.length(); i++) {
            final int ix = i;
            JSONObject o = obj(a, i);
            double debt = o.optDouble("debt", 0);
            LinearLayout c = card();
            c.addView(tv(o.optString("name"), 18, TEXT, true));
            String contact = o.optString("contact", "");
            c.addView(tv("التواصل: " + (contact.isEmpty() ? "غير مضاف" : contact), 14, Color.DKGRAY, false));
            c.addView(tv("الدين: " + money(debt), 16, debt > 0 ? RED : GREEN, true));
            Button open = btn("فتح حساب العميل");
            open.setOnClickListener(v -> showCustomerDetails(ix));
            c.addView(open, lp(44));
            content.addView(c, wrap());
            addSpace(8);
        }
    }

    void customerDialog(final int index) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(8), dp(16), dp(4));
        final EditText name = field("اسم العميل", 0);
        final EditText contact = field("رقم الهاتف / التواصل", 0);
        box.addView(name);
        box.addView(contact);
        if (index >= 0) {
            JSONObject cur = obj(customers(), index);
            name.setText(cur.optString("name"));
            contact.setText(cur.optString("contact"));
        }
        AlertDialog.Builder builder = new AlertDialog.Builder(this)
                .setTitle(index < 0 ? "إضافة عميل" : "تعديل بيانات العميل")
                .setView(box)
                .setNegativeButton("إلغاء", null);
        builder.setPositiveButton("حفظ", (d, w) -> {
            try {
                String nm = name.getText().toString().trim();
                if (nm.isEmpty()) throw new Exception();
                JSONArray all = customers();
                JSONObject o = index < 0 ? new JSONObject() : all.getJSONObject(index);
                o.put("name", nm);
                o.put("contact", contact.getText().toString().trim());
                if (!o.has("debt")) o.put("debt", 0);
                if (!o.has("history")) o.put("history", new JSONArray());
                if (!o.has("id")) o.put("id", String.valueOf(System.currentTimeMillis()));
                if (index < 0) all.put(o);
                save("customers", all);
                showCustomers();
            } catch (Exception e) {
                toast("أدخل اسم العميل.");
            }
        });
        if (index >= 0) builder.setNeutralButton("حذف", (d, w) -> deleteCustomer(index));
        builder.show();
    }

    void deleteCustomer(final int index) {
        JSONObject o = obj(customers(), index);
        if (o.optDouble("debt", 0) > 0) {
            toast("لا يمكن حذف عميل عليه دين. سدّد الدين أولاً.");
            return;
        }
        new AlertDialog.Builder(this).setTitle("حذف العميل")
                .setMessage("هل تريد حذف هذا العميل؟")
                .setNegativeButton("إلغاء", null)
                .setPositiveButton("حذف", (d, w) -> {
                    JSONArray all = customers();
                    all.remove(index);
                    save("customers", all);
                    showCustomers();
                }).show();
    }

    void showCustomerDetails(final int index) {
        JSONObject o = obj(customers(), index);
        double debt = o.optDouble("debt", 0);
        clear("حساب العميل");
        content.addView(tv(o.optString("name"), 22, TEXT, true));
        String contact = o.optString("contact", "");
        content.addView(tv("التواصل: " + (contact.isEmpty() ? "غير مضاف" : contact), 14, Color.DKGRAY, false));
        addSpace(8);

        LinearLayout bal = card();
        bal.addView(tv("الدين الحالي", 14, Color.DKGRAY, false));
        bal.addView(tv(money(debt), 28, debt > 0 ? RED : GREEN, true));
        content.addView(bal, wrap());
        addSpace(10);

        Button plus = btn("+ إضافة دين");
        plus.setOnClickListener(v -> changeDebt(index, true));
        content.addView(plus, lp(48));
        addSpace(8);
        Button minus = btn("− سداد / خصم من الدين");
        minus.setOnClickListener(v -> changeDebt(index, false));
        content.addView(minus, lp(48));
        addSpace(8);
        Button edit = btn("تعديل بيانات العميل");
        edit.setOnClickListener(v -> customerDialog(index));
        content.addView(edit, lp(48));
        addSpace(12);

        LinearLayout h = card();
        h.addView(tv("سجل الدين", 16, TEXT, true));
        JSONArray hist = o.optJSONArray("history");
        if (hist == null || hist.length() == 0) {
            h.addView(tv("لا توجد عمليات بعد.", 14, Color.DKGRAY, false));
        } else {
            for (int j = hist.length() - 1; j >= 0; j--) {
                JSONObject z = obj(hist, j);
                String line = (z.optBoolean("add") ? "+ دين  " : "− سداد  ") + money(z.optDouble("amount", 0)) + " — " + z.optString("time");
                String note = z.optString("note", "");
                if (!note.isEmpty()) line += "\n" + note;
                h.addView(tv(line, 14, TEXT, false));
            }
        }
        content.addView(h, wrap());
    }

    void changeDebt(final int index, final boolean add) {
        final EditText amount = field(add ? "مبلغ الدين" : "مبلغ السداد", 1);
        new AlertDialog.Builder(this).setTitle(add ? "إضافة دين" : "سداد / خصم")
                .setView(amount)
                .setNegativeButton("إلغاء", null)
                .setPositiveButton("حفظ", (d, w) -> {
                    try {
                        double val = Double.parseDouble(amount.getText().toString().trim());
                        if (val <= 0) throw new Exception();
                        JSONArray all = customers();
                        JSONObject o = all.getJSONObject(index);
                        double debt = o.optDouble("debt", 0);
                        if (!add && val > debt) throw new Exception();
                        o.put("debt", add ? debt + val : debt - val);
                        JSONArray hist = o.optJSONArray("history");
                        if (hist == null) hist = new JSONArray();
                        JSONObject z = new JSONObject();
                        z.put("amount", val);
                        z.put("add", add);
                        z.put("time", now());
                        hist.put(z);
                        o.put("history", hist);
                        all.put(index, o);
                        save("customers", all);
                        showCustomerDetails(index);
                    } catch (Exception e) {
                        toast(add ? "أدخل مبلغاً صحيحاً." : "مبلغ السداد أكبر من الدين أو غير صحيح.");
                    }
                }).show();
    }

    // ---------- BACKUP & RESTORE ----------
    void showBackup() {
        clear("النسخ الاحتياطي");
        LinearLayout info = card();
        info.addView(tv("بياناتك (المنتجات، المبيعات، المصروفات، العملاء) محفوظة على هذا الهاتف فقط. "
                + "إذا ضاع الهاتف أو حُذف التطبيق تضيع البيانات. احفظ نسخة في ملف وأرسلها لنفسك (واتساب أو بريد أو Google Drive).", 14, TEXT, false));
        String last = pref("last_backup", "");
        info.addView(tv(last.isEmpty() ? "لم تُحفظ أي نسخة بعد." : "آخر نسخة: " + last, 14, last.isEmpty() ? ORANGE : GREEN, true));
        content.addView(info, wrap());
        addSpace(12);

        Button saveBtn = btn("💾  حفظ نسخة احتياطية");
        saveBtn.setOnClickListener(v -> startExport());
        content.addView(saveBtn, lp(52));
        addSpace(8);
        Button restoreBtn = btn("📂  استعادة من نسخة");
        restoreBtn.setOnClickListener(v -> startImport());
        content.addView(restoreBtn, lp(52));
        addSpace(10);
        content.addView(tv("الاستعادة تستبدل كل البيانات الحالية بمحتوى النسخة.", 13, Color.DKGRAY, false));
    }

    void startExport() {
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/json");
        i.putExtra(Intent.EXTRA_TITLE, "mutajri_backup_" + dateOnly() + ".json");
        startActivityForResult(i, REQ_EXPORT);
    }

    void startImport() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        startActivityForResult(i, REQ_IMPORT);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        if (requestCode == REQ_EXPORT) writeBackup(uri);
        else if (requestCode == REQ_IMPORT) readBackup(uri);
    }

    void writeBackup(Uri uri) {
        try {
            JSONObject backup = new JSONObject();
            backup.put("app", "mutajri");
            backup.put("version", 1);
            backup.put("exported", now());
            for (String k : DATA_KEYS) backup.put(k, arr(k));
            OutputStream os = getContentResolver().openOutputStream(uri);
            os.write(backup.toString(2).getBytes("UTF-8"));
            os.close();
            put("last_backup", now());
            toast("تم حفظ النسخة الاحتياطية ✓");
            showBackup();
        } catch (Exception e) {
            toast("تعذر حفظ النسخة الاحتياطية.");
        }
    }

    void readBackup(Uri uri) {
        try {
            InputStream is = getContentResolver().openInputStream(uri);
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int r;
            while ((r = is.read(buf)) > 0) bo.write(buf, 0, r);
            is.close();
            final JSONObject backup = new JSONObject(bo.toString("UTF-8"));
            if (!"mutajri".equals(backup.optString("app"))) throw new Exception();
            new AlertDialog.Builder(this).setTitle("استعادة النسخة")
                    .setMessage("ستُستبدل كل البيانات الحالية بمحتوى هذه النسخة (" + backup.optString("exported") + "). هل تريد المتابعة؟")
                    .setNegativeButton("إلغاء", null)
                    .setPositiveButton("استعادة", (d, w) -> {
                        SharedPreferences.Editor ed = prefs.edit();
                        for (String k : DATA_KEYS) {
                            JSONArray part = backup.optJSONArray(k);
                            if (part == null) part = new JSONArray();
                            ed.putString(k, part.toString());
                        }
                        ed.putBoolean("shift_active", false).putString("shift_id", "")
                                .putString("shift_start", "").putString("current_notes", "");
                        ed.apply();
                        migrateOldData();
                        toast("تمت الاستعادة ✓");
                        showHome();
                    }).show();
        } catch (Exception e) {
            toast("الملف غير صالح. اختر ملف نسخة احتياطية من التطبيق.");
        }
    }
}
